public class BarangElektronik extends Barang {
    //Atribut

    // Constructor BarangElektronik


    // Getter dan Setter untuk garansi

    // Override method tampilkanData
    @Override
    public void tampilkanData() {
        super.tampilkanData();
        // Tampilan

    }
}
