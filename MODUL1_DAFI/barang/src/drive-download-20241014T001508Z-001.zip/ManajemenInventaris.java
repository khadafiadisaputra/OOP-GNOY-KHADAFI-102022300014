import java.util.ArrayList;
import java.util.Scanner;

public class ManajemenInventaris {
    // Deklarasi ArrayList untuk menyimpan barang


    // Method untuk menambah barang elektronik

        // Scanner 

        // Input Nama Barang, Jumlah Barang, Harga Barang, Garansi Barang

        // Membuat objek barang elektronik baru


    // Method untuk menambah barang non-elektronik

        // Scanner


        // Input Nama Barang, Jumlah Barang, Harga Barang, Material Barang

        // Membuat objek barang non-elektronik baru


    // Method untuk menampilkan semua barang memakai if-else (jika tidak ada barang akan menampilkan tidak ada barang dalam inventaris)

}
