public class Barang {
    //Atribut

    // Constructor Barang


    // Getter dan Setter


    // Method tampilkanData

}
